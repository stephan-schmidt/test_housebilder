// Household builder
// Your application needs a way to capture information about a household applying for health insurance coverage. Develop a UI for building a household up from individual people.
//
// Task
// You have been given an HTML page with a form and a placeholder for displaying a household.
//
// In the given index.js file, replace the "Your code goes here" comment with JavaScript that can:
//
// Validate data entry (age is required and > 0, relationship is required)
// Add people to a growing household list
// Remove a previously added person from the list
// Display the household list in the HTML as it is modified
// Serialize the household as JSON upon form submission as a fake trip to the server
// Notes
// Don't modify the given index.html file in any way. You're of course still allowed to modify the DOM through Javascript.
//
// You must write JavaScript, not a language that compiles down to JavaScript. You must use ES3 or ES5/5.1 standard. Assume the capabilities of a modern mainstream browser in wide use, i.e., no bleeding-edge features. No 3rd party libraries — i.e., no jQuery.
//
// The display of the household list is up to you.
//
// On submission, put the serialized JSON in the provided "debug" DOM element and display that element.
//
// After submission, the user should be able to make changes and submit the household again.
//
// You don't need to add validations around anything other than the age and relationship requirements described above. It's ok for someone to add 35 parents.
//
// The focus here is on the quality of your JavaScript, not the beauty of your design. The controls you add around viewing and deleting household members should be usable but need not be much to look at.
//
// Included files
// Here are the files we'll give to you to get you started. Download them when you are ready to begin.
//
// Ready to submit?
// Don't include anything in your files that could identify you. We assign submissions a random number when they are received so our team does not know whose homework they are evaluating. Multiple team members will review your submission before a decision is made.


// your code goes here ...





var entP = '';
// var debuggerVar = getCookie('json_obj');
// var debuggerList = document.querySelector(".debug");
// debuggerList.innerHTML = debuggerVar;
var housholdList = document.querySelector(".household");
// housholdList.innerHTML += "<li> AGE  | RELATIONSHIP | SMOKER | DELETE</li>"



// Build up the list
var cookieP = getCookie('household');
var cookiePObj = cookieP.split(',');
cookiePObj.splice(-1,1);
for (var i = 0; i <cookiePObj.length; i++){
  console.log(cookiePObj[0]);
  if(cookiePObj[0] != '')housholdList.innerHTML+= "<li class='member' valm='"+i+"'>"+cookiePObj[i].split('|')[0]+" | "+cookiePObj[i].split('|')[1]+" | x</li>";
}





var housholdList = document.querySelector(".household");




// get Age value
var inputAge = 0;
var inputAgeEl = document.querySelector("input[name]");
const ageHandler = function(e) {
  inputAge = e.target.value;
}
inputAgeEl.addEventListener('input', ageHandler)

// get Relationship value
var selectRvar = '';
var selectR = document.querySelector("select");
const selectRhandler = function(e) {
  selectRvar = e.target.options[e.target.selectedIndex].innerText;
}
selectR.addEventListener('change', selectRhandler);

// add Row btn
var addBtn = document.querySelectorAll('button.add');
addBtn[0].onclick = function() {
    valNum();
}

// submit btn
var submitBtn = document.querySelectorAll('button[type]');
submitBtn[0].onclick = function() {
    viewL();

}

/// adds to the list

function addPfunc ()
{

cookieP += inputAge + "|" + selectRvar+",";
setCookie('household',cookieP,'99999');

}

// get element to delete
document.addEventListener('click', function(e) {
    var target = e;
    remPfunc (target)

}, false);
function remPfunc (el)
{

  if (el.target.className == 'member' && !isNaN(el.target.attributes[1].value)){

    cookiePObj.splice(el.target.attributes[1].value,1)
    setCookie('household',cookiePObj.toString()+',','99999');
    window.location.reload();
  }

}

/// validiert ager
function valNum ()
{

  if (inputAge>0 && inputAge!='' && !isNaN(inputAge)==true)
  {
      valSel();
  }else
  {
      alert('Please enter a valid Age.'); return false;
  }


  // Validate data entry (age is required and > 0, relationship is required)
}
/// validate selection

function valSel ()
{
// if (inputAge<=0 || !isNaN(inputAge) && selectRvar !== '' || selectRvar !== '---')addPfunc ()
  if (selectRvar != '' && selectRvar != '---')
  {
    addPfunc ();
  }
  else
  {
    alert('Please select a Relationship.'); return false;
  }
}

function viewL ()
{
      // cookiePObj
      // var temp = JSON.stringify(cookiePObj);
      // for()
        // var temp =   JSON.stringify(cookiePObj);
        // setCookie('json_obj', temp, '9999');
        var debuggerList = document.querySelector(".debug");
        debuggerList.innerHTML = cookiePObj;

        //////////////////
        // Alternative approach - writing the object in a testobject in the local torage
        // eg var debuggerVar ={age:"12", rel:"Child"};
        // localStorage.setItem('listhousehold', JSON.stringify(debuggerVar));
        // var retrievedObject = localStorage.getItem('listhousehold');
        // console.log('listhousehold: ', JSON.parse(retrievedObject));
        // ////

}

//// Cookie Handler
function setCookie(cname, cvalue, exdays) {
  var d = new Date();
  d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
  var expires = "expires="+d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
  var name = cname + "=";
  var ca = document.cookie.split(';');
  for(var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function checkCookie() {
  var user = getCookie("username");
  if (user != "") {
    alert("Welcome again " + user);
  } else {
    user = prompt("Please enter your name:", "");
    if (user != "" && user != null) {
      setCookie("username", user, 365);
    }
  }
}